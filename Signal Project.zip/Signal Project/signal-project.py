#Keneth Hudgins
#
#Started: 2/21/18
#Finished: 2/28/18
#
#Speech Signal Analysis Project
#
#Problem Description: Compare two files that hold the values from two
#different sound recordings to determine if they are the same using 
#vectors
#
#NOTE: If any of the values are wrong, Its more than likely because
#I didnt understand the formulas and coded them wrong.
####
#####
######
#######
########
################################################
##################################################
# THE BELOW ARE FUNCTIONS    #  #  #  #  #  #  ####
##################################################
################################################
########
#######
######
#####
####


##############################################
# FUNCTION: mean_A                         ###
# Finds mean value of two_a.txt file data ####
##############################################
def mean_A():
    total_of_filea_data = 0
    mean_A=0
    
    file_a = open("two_a.txt","r").read().splitlines()
    i = 0
    for line in file_a:
       file_a[i] = float(file_a[i])
       i = i +1
     

    x = 0
    for line in file_a:
       total_of_filea_data = total_of_filea_data + float(file_a[x])
       x = x + 1
       
    mean_A=total_of_filea_data/i
    return mean_A
##########################
# End of mean_A function #
##########################





##############################################
# FUNCTION: mean_B                         ###
# Finds mean value of two_b.txt file data ####
##############################################
def mean_B():
    total_of_fileb_data = 0
    mean_B=0
    
    file_b = open("two_b.txt","r").read().splitlines()
    i = 0
    for line in file_b:
       file_b[i] = float(file_b[i])
       i = i +1
     

    x = 0
    for line in file_b:
       total_of_fileb_data = total_of_fileb_data + float(file_b[x])
       x = x + 1
       
    mean_B=total_of_fileb_data/i
    return mean_B
##########################
# End of mean_B function #
##########################





##################################################
# FUNCTION: a_variance                         ###
# Finds variance value of two_a.txt file data ####
##################################################
def a_variance(a_mean):
    file_a = open("two_a.txt","r").read().splitlines()
    i = 0
    total_temp=0
    variance=0
    xtemp = 0
    temp=[]
    for line in file_a:
       xtemp = (((float(file_a[i])) - a_mean)**2)
       temp.append(xtemp)
       i = i +1
    i=0
    for line in temp:
        total_temp = total_temp + temp[i]
        i=i+1
    variance=total_temp/i
    return variance
##############################
# End of a_variance function #
##############################





##################################################
# FUNCTION: b_variance                         ###
# Finds variance value of two_b.txt file data ####
##################################################
def b_variance(b_mean):
    file_b = open("two_b.txt","r").read().splitlines()
    i = 0
    total_temp=0
    variance=0
    xtemp = 0
    temp=[]
    for line in file_b:
       xtemp = (((float(file_b[i])) - b_mean)**2)
       temp.append(xtemp)
       i = i +1
    i=0
    for line in temp:
        total_temp = total_temp + temp[i]
        i=i+1
    variance=total_temp/i
    return variance
##############################
# End of a_variance function #
##############################






############################################################
# FUNCTION: a_stdDev                                     ###
# Finds standard deviation value of two_a.txt file data ####
############################################################
def a_stdDev(a_v):
    from math import sqrt
    stdv = sqrt(a_v)
    return stdv
############################
# End of a_stdDev function #
############################







############################################################
# FUNCTION: b_stdDev                                     ###
# Finds standard deviation value of two_b.txt file data ####
############################################################
def b_stdDev(b_v):
    from math import sqrt
    stdv = sqrt(b_v)
    return stdv
############################
# End of a_stdDev function #
############################








###########################################################
# FUNCTION: a_avgPwr                                    ###
# Finds the average power value of two_a.txt file data ####
###########################################################
def a_avgPwr():
    file_a = open("two_a.txt","r").read().splitlines()
    i = 0
    total_temp=0
    xtemp = 0
    for line in file_a:
       xtemp = (float(file_a[i])**2)
       total_temp = total_temp + xtemp
       i = i +1
    avgp = total_temp / i
    return avgp
############################
# End of a_avgPwr function #
############################









###########################################################
# FUNCTION: b_avgPwr                                   ####
# Finds the average power value of two_b.txt file data ####
###########################################################
def b_avgPwr():
    file_b = open("two_b.txt","r").read().splitlines()
    i = 0
    total_temp=0
    xtemp = 0
    for line in file_b:
       xtemp = (float(file_b[i])**2)
       total_temp = total_temp + xtemp
       i = i +1
    avgp = total_temp / i
    return avgp
############################
# End of a_avgPwr function #
############################








##############################################################
# FUNCTION: a_avgMgntd                                      ##
# Finds the average magnitude value of two_a.txt file data ###
##############################################################
def a_avgMgntd():
    import math
    file_a = open("two_a.txt","r").read().splitlines()
    i = 0
    temp = 0
    total = 0
    for line in file_a:
       temp = abs(float(file_a[i]))
       total = total + temp
       i = i +1
    avgm = total / i
    return avgm
##############################
# End of a_avgMgntd function #
##############################









###############################################################
# FUNCTION: b_avgMgntd                                      ###
# Finds the average magnitude value of two_b.txt file data ####
###############################################################
def b_avgMgntd():
    import math
    file_b = open("two_b.txt","r").read().splitlines()
    i = 0
    temp = 0
    total = 0
    for line in file_b:
       temp = abs(float(file_b[i]))
       total = total + temp
       i = i +1
    avgm = total / i
    return avgm
##############################
# End of b_avgMgntd function #
##############################







################################################################
# FUNCTION: a_zroCrs                                          ##
# Finds the number of zero crosses in the two_a.txt file data ##
################################################################
def a_zroCrs():
    zc = 0
    i = 0
    file_a = open("two_a.txt","r").read().splitlines()
    while i < (len(file_a))-2:
        if (((float(file_a[i]) > 0)&(float(file_a[i + 1]) < 0)) | ((float(file_a[i]) < 0)&(float(file_a[i + 1]) > 0))):
            zc = zc + 1
        i = i +1
    return zc
############################
# End of a_zroCrs function #
############################









################################################################
# FUNCTION: b_zroCrs                                          ##
# Finds the number of zero crosses in the two_b.txt file data ##
################################################################
def b_zroCrs():
    zc = 0
    i = 0
    file_b = open("two_b.txt","r").read().splitlines()
    while i < (len(file_b))-2:
        if (((float(file_b[i]) > 0)&(float(file_b[i + 1]) < 0)) | ((float(file_b[i]) < 0)&(float(file_b[i + 1]) > 0))):
            zc = zc + 1
        i = i +1
    return zc
############################
# End of b_zroCrs function #
############################






################################################################
# FUNCTION: display_table                                     ##
# Displays data collected from the two_a and two_b text files ##
# in a table for comparison                                   ##
################################################################
def display_table(a_mean, b_mean, a_v, b_v, a_std, b_std, a_ap, b_ap, a_am, b_am, a_zc, b_zc):
    print("Project by Kenneth Hudgins\n")
    print("Description: Compare different speech signal data sets \n")
    print("                            Two_a.txt                Two_b.txt\n")
    print("Mean:                       {0:.9f}".format(a_mean) + "              {0:.9f}".format(b_mean) + "\n")
    print("Varience:                   {0:.9f}".format(a_v) + "              {0:.9f}".format(b_v) + "\n")
    print("Standard Deviation:         {0:.9f}".format(a_std) + "              {0:.9f}".format(b_std)+ "\n")
    print("Zero Crosses:                   "+ str(a_zc) + "                      " + str(b_zc) + "\n")
    print("Average Magnitude:          {0:.9f}".format(a_am) + "              {0:.9f}".format(b_am) + "\n")
    print("Average Power:              {0:.9f}".format(a_ap) + "              {0:.9f}".format(a_ap) + "\n")
    print(" \n")
    print("B) Average Magnitude, Standard Deviation, and Mean seam to be the closest values \n")
    print("C) Average Power, Varience, and Zero Crosses seem to be the most different \n")
    print("D) I have no experience with voice analysis so I cant really say what other \n")
    print("statistical measures would help.\n")
    print("E) I would say they are indeed by the same person, though talking in a different \n")
    print("tone in each sample. \n")
    print(" \n")


#################################
# End of display_table function #
#################################






#   
###
#####
#######
#########
###########
###########
##    #####
####  #####
####     ##
##     ####
##     ####
####     ##
####  #####
##    #####
###########
#*******************************************
############################################
##                                         #
##     MAIN FUNCTION                       #
##                                         #
############################################
#*******************************************
a_mean = mean_A()
b_mean = mean_B()
a_v = a_variance(a_mean)
b_v = b_variance(b_mean)
a_std = a_stdDev(a_v)
b_std = b_stdDev(b_v)
a_ap = a_avgPwr()
b_ap = b_avgPwr()
a_am = a_avgMgntd()
b_am = b_avgMgntd()
a_zc = a_zroCrs()
b_zc = b_zroCrs()
display_table(a_mean, b_mean, a_v, b_v, a_std, b_std, a_ap, b_ap, a_am, b_am, a_zc, b_zc)


